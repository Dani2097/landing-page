import Mission from "./Mission";
import Numbe from "./Numbe";

export default function AboutContent(props){
    return<div>
        <Mission/>
        <Numbe/>
    </div>
}