import React from "react";
import {Button, TextField, Typography} from "@material-ui/core";
import {SendOutlined, SendRounded} from "@material-ui/icons";

export default function ContactUs(props) {
    return <div className={"contact-card"}>
        <Typography className={"contact-title"}>CONTATTACI</Typography>
        <form>
            <TextField className={"contact-field"}  label={"Nome"} name={"name"}/>
            <TextField className={"contact-field"} label={"Email"} name={"Email"}/>
            <TextField
                className={"contact-field"}
                       multiline
                       rows={4}
                       label={"Messaggio"}
                       name={"Content"}
            />
            <Button variant={"outlined"} color={"primary"} className={"contact-button"}>Invia  <SendOutlined style={{marginLeft:4}}/></Button>
        </form>
    </div>
}