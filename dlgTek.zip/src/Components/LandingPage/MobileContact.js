import React from "react";
import ContactUs from "./ContactUs";
import bg from "../../assets/bg-contact.jpg"

export default function MobileContact() {
    return <div id={"mobile-contact"}>
        <img src={bg} style={{position:"absolute"}} alt={"back"}/>
        <ContactUs/>
    </div>
}