import React from "react";
import absel from "../../assets/project-logo/abseel.png"
import leduran from "../../assets/project-logo/leduran.png"
import euklid from "../../assets/project-logo/euclid.png"
import amilcare from "../../assets/project-logo/amilcare.gif"
import pianoweb from "../../assets/project-logo/pianoweb.png"
import quaternion from "../../assets/project-logo/quaternion.png"
import laborvetro from "../../assets/project-logo/laborvetro.png"
import abyss from "../../assets/project-logo/abyss.png"
import {Link, List, ListItem, ListItemText, Typography} from "@material-ui/core";

const projects = {
    web: [
        {
            image: absel,
            descriptions: ['Progettazione e realizzazione sito e-commerce del settore moda'],
            link: 'https://abse-el.it'
        },
        {
            image: leduran,
            descriptions: ['Realizzazione sito web basato su CMS Wordpress', 'Implementazione plugin Woocommerce per la gestione del catalogo prodotti'],
            link: 'https://www.leduran.com'
        },
        {
            image: euklid,
            descriptions: [
                'Progettazione, realizzazione e manutenzione piattaforma web per la creazione e la gestione ordini di trading, reporting e statistiche.',
                'Realizzazione sistema di controllo avanzato piattaforma con alert automatici.',
            ]
        }
    ],
    server: [
        {
            image:laborvetro,
            descriptions: [
                'Riprogettazione e implementazione rete aziendale.',
                'Configurazione sistemi di backup dati',
                'Manutenzione sistemi informatici aziendali'
            ]
        },
        {
            image: euklid,
            descriptions: [
                'Realizzazione sistema per la memorizzazione di segnali sulla blockchain di Bitcoin.',
                'Progettazione, realizzazione e manutenzione server web.'
            ]
        },
        {
            image: amilcare,
            descriptions: [' Realizzazione, gestione e manutenzione infrastruttura server.']
        },
        {
            image: pianoweb,
            descriptions: ['Realizzazione di endpoint ad-hoc per l\'interfacciamento tra appicazione e wordpress'],
            link: 'https://play.google.com/store/apps/details?id=com.caschi',
            linkname: 'Applicazione android'
        },
        {
            image: quaternion,
            descriptions: [
                'Configurazione e messa in sicurezza della rete aziendale.',
                'Realizzazione di software per l’automazione di processi aziendali successivamente installati su server Linux e Windows appositamente configurati e gestiti quotidianamente dal team DLG TEK.',
                'Sviluppo in C# di un sistema di interfacciamento con un noto broker di trading per l’esecuzione di operazioni a mercato'
            ]
        }
    ],
    mobile: [
        {
            image: amilcare,
            descriptions: ['Sviluppo app mobile & web di controllo del dispositivo', 'Progettazione dispositivo IoT / Stampa 3D']
        },
        {
            image: pianoweb,
            descriptions: ['Realizzazione app OSBE Helmets Club per piattaforme Android e iOS.'],
            link: 'https://play.google.com/store/apps/details?id=com.caschi',
            linkname: 'Applicazione android'
        }
    ],
    game:[
        {
            image:abyss,
            descriptions:[
                'Design, progettazione, sviluppo e realizzazione dell\'applicazione videoludica Abyss rings',
                'Progettazione dei modelli 3D utilizzati dall\' applicazione',
                'Sviluppo delle interfaccie per la comunicazione client server'
            ],
            link: 'https://play.google.com/store/apps/details?id=com.DLGTEK.WaterSplashRings3D',
            linkname: 'Applicazione android'
        }
    ]
}
const type = ['web', 'mobile', 'server', 'game'];
export default function Project(props) {
    const selectedType = type[props.selected];
    return <div>
        <div className={'project-container'}>
            {!props.noTitle && <Typography className={'title'}>Lavori realizzati </Typography>}
            <div className={"flex"} style={{flexWrap: 'wrap'}}>
                {projects[selectedType]?.map(e => <div className={"single-product"}>
                        <img src={e.image} alt={"logo"} className={"project-image"}/>
                        <List style={{minHeight: 100}}>
                            {e.descriptions.map(el => <ListItem>
                                <div className={"dot"}/>
                                &nbsp;<ListItemText>{el}</ListItemText></ListItem>)}
                        </List>
                        {e.link && <Link target={"_blank"} href={e.link} style={{
                            alignSelf: "flex-start",
                            paddingLeft: 20,
                            color: "#004cff"
                        }}>{e.linkname || e.link}</Link>}
                    </div>
                )}</div>
        </div>
    </div>
}