import {Typography} from "@material-ui/core";

export default function MainFooter(){
    return<div id={"footer"}>
        <div>
            <Typography>DLG TEK S.R.L.S. - P.IVA 01828210706 - info@dlgtek.com</Typography>
        </div>
    </div>
}