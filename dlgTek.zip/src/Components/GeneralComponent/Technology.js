import {
    gitLogo,
    phpLogo,
    pythonLogo,
    mysqlLogo,
    mongoLogo,
    reactLogo,
    hibernateLogo,
    awsLogo,
    springLogo,
    ciLogo,
    nodeLogo,
    expressLogo,
    cssLogo,
    jsLogo,
    htmlLogo,
    rnLogo,
    magentoLogo,
    prestashopLogo,
    wordpressLogo,
    androidLogo,
    ionicLogo,
    angularLogo,
    iosLogo,
    cordovaLogo,
    unityLogo,
    ueLogo,
    godotLogo,
    curaLogo,
    sketchLogo,
    blenderLogo
} from "../../assets/TechnologyLogo/IndexImages";
import {Typography} from "@material-ui/core";

const gameLogos = [unityLogo, ueLogo, godotLogo, curaLogo, sketchLogo, blenderLogo];
const webLogos = [cssLogo, jsLogo, htmlLogo, reactLogo, magentoLogo, prestashopLogo, wordpressLogo, angularLogo];
const mobileLogos = [ionicLogo, angularLogo, rnLogo, androidLogo, iosLogo, cordovaLogo]
const backendLogos = [hibernateLogo, awsLogo, springLogo, mysqlLogo, mongoLogo, ciLogo, nodeLogo, expressLogo, phpLogo, pythonLogo]
const allLogos = [webLogos, mobileLogos, backendLogos, gameLogos]
export default function Technology(props) {
    let imgToRender = allLogos[props.index || 0];
    return <div id={"technology"}>
        <div>
            {!props.noTitle && <Typography>Tecnologie di riferimento </Typography>}
                <div className={"technology-container"}
                     style={{width: window.innerWidth < 860 && window.innerWidth - 40}}>
                    {imgToRender.map(e => <img src={e} className={"technology-image"} alt={'tecLogo'}/>)}
                </div>
        </div>
    </div>
}