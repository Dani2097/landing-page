import logo from './logo.svg';
import './App.css';
import MainHeader from "./Components/GeneralComponent/MainHeader";
import Content from "./Components/LandingPage/Content";
import MainFooter from "./Components/GeneralComponent/MainFooter";
import {BrowserRouter as Router, Route, Routes} from "react-router-dom";
import Abyss from "./Components/Abyss/Abyss";
import About from "./Components/About/About";
import 'animate.css';
import './animating.css'
function App() {
    return (
    <div className="App">
        <Router>
            <MainHeader/>
        <Routes >
            <Route exact path={'/'} element={<Content/>}/>
            <Route exact path={'/abyss'} element={<Abyss/>}/>
            <Route exact path={'/about'} element={<About/>}/>
        </Routes>
        </Router>
      <MainFooter/>
    </div>
  );
}

export default App;
